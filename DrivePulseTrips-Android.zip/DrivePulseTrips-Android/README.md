# DrivePulseTrips Android App

A Material Design 3 Android app that reads car trip telemetry from `Sheet1` of your **DrivePulse** Google Sheet, displays each trip on its own swipeable page, opens GPS coordinates in Google Maps, and lets you delete trips directly from the sheet.

## 1. Connect Your `DrivePulse` Google Sheet (60 seconds)
1. Open your **DrivePulse** Google Sheet.
2. Click **Extensions → Apps Script**.
3. Delete any default code and paste the contents of `google-apps-script/Code.gs`.
4. Click **Deploy → New deployment**.
5. Select type **Web app**:
   - **Execute as:** Me
   - **Who has access:** Anyone
6. Click **Deploy**, authorize permissions, and copy the **Web app URL** (ends with `/exec`).

## 2. Build the APK via GitHub Actions
1. Create a new GitHub repository and upload/push all files from this ZIP (including `.github/workflows/build.yml`).
2. Open the **Actions** tab in your GitHub repository.
3. Click the **Build DrivePulseTrips APK** workflow run (runs automatically on push to `main`/`master`, or click **Run workflow**).
4. Download the **DrivePulseTrips-APK** artifact, unzip it, and install `app-debug.apk` on your Android phone.

## 3. Configure the App
1. Open **DrivePulseTrips** on your phone.
2. Tap **Set Google Sheet URL** (or the gear icon in the top right) and paste your Web App URL.
3. Tap **Save & Sync** to load all rows from `Sheet1`.

# DrivePulse ProGuard rules
-keep class com.drivepulse.viewer.model.** { *; }

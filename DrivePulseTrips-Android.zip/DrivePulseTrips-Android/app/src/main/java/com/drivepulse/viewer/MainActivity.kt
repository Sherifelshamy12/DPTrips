package com.drivepulse.viewer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.drivepulse.viewer.ui.DrivePulseScreen
import com.drivepulse.viewer.ui.theme.DrivePulseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DrivePulseTheme {
                DrivePulseScreen()
            }
        }
    }
}

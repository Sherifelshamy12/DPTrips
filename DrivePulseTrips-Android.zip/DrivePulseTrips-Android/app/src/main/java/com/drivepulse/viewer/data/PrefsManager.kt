package com.drivepulse.viewer.data

import android.content.Context

class PrefsManager(context: Context) {
    private val prefs = context.getSharedPreferences("drivepulse_prefs", Context.MODE_PRIVATE)

    var scriptUrl: String
        get() = prefs.getString(KEY_SCRIPT_URL, "")?.trim().orEmpty()
        set(value) {
            prefs.edit().putString(KEY_SCRIPT_URL, value.trim()).apply()
        }

    companion object {
        private const val KEY_SCRIPT_URL = "apps_script_url"
    }
}

package com.drivepulse.viewer.data

import com.drivepulse.viewer.model.Trip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class SheetsRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    suspend fun fetchTrips(scriptUrl: String): Result<List<Trip>> = withContext(Dispatchers.IO) {
        try {
            val baseUrl = scriptUrl.trim().toHttpUrlOrNull()
                ?: return@withContext Result.failure(IllegalArgumentException("Invalid Web App URL."))

            val url = baseUrl.newBuilder()
                .addQueryParameter("action", "getTrips")
                .build()

            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IOException("HTTP ${response.code}: Failed to fetch Sheet1.")
                    )
                }

                val trimmed = body.trim()
                if (trimmed.startsWith("<")) {
                    return@withContext Result.failure(
                        IOException("Received HTML instead of JSON. Check that your Apps Script Web App access is set to 'Anyone'.")
                    )
                }

                val root = JSONObject(trimmed)
                if (root.optString("status") == "error") {
                    return@withContext Result.failure(
                        IOException(root.optString("message", "Unknown Apps Script error"))
                    )
                }

                val array = root.optJSONArray("trips") ?: JSONArray()
                val trips = mutableListOf<Trip>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    trips.add(parseTrip(obj))
                }
                Result.success(trips)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTrip(
        scriptUrl: String,
        rowNumber: Int,
        tripStartTime: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val baseUrl = scriptUrl.trim().toHttpUrlOrNull()
                ?: return@withContext Result.failure(IllegalArgumentException("Invalid Web App URL."))

            val payload = JSONObject().apply {
                put("action", "deleteTrip")
                put("rowNumber", rowNumber)
                put("tripStartTime", tripStartTime)
            }

            val requestBody = payload.toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(baseUrl)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty().trim()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IOException("HTTP ${response.code}: Failed to delete trip.")
                    )
                }
                if (body.startsWith("<")) {
                    return@withContext Result.failure(
                        IOException("Received HTML instead of JSON. Re-deploy your Apps Script with access set to 'Anyone'.")
                    )
                }
                val root = JSONObject(body)
                if (root.optString("status") == "ok") {
                    Result.success(Unit)
                } else {
                    Result.failure(IOException(root.optString("message", "Delete failed.")))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseTrip(obj: JSONObject): Trip {
        fun str(vararg keys: String): String {
            for (k in keys) {
                if (obj.has(k) && !obj.isNull(k)) {
                    return obj.optString(k, "").trim()
                }
            }
            return ""
        }

        return Trip(
            rowNumber = obj.optInt("rowNumber", -1),
            startName = str("Start name", "startName").ifBlank { "Start" },
            endName = str("End name", "endName").ifBlank { "Destination" },
            startLocation = str("Start location", "startLocation"),
            endLocation = str("End location", "endLocation"),
            tripStartTime = str("Trip start time", "tripStartTime"),
            tripEndTime = str("Trip end time", "tripEndTime"),
            tripDuration = str("Trip duration", "tripDuration"),
            tripDistance = str("Trip distance", "tripDistance"),
            maxSpeed = str("Max speed", "maxSpeed"),
            tripAvgSpeed = str("Trip avg speed", "tripAvgSpeed"),
            sharpTurns = str("Sharp turns", "sharpTurns"),
            topLateralG = str("Top lateral G", "topLateralG"),
            chauffeurSmoothAccel = str("Chauffeur-Smooth accel", "chauffeurSmoothAccel"),
            comfortableEverydayAccel = str("Comfortable Everyday accel", "comfortableEverydayAccel"),
            noticeableBriskAccel = str("Noticeable / Brisk accel", "noticeableBriskAccel"),
            uncomfortableAccel = str("Uncomfortable accel", "uncomfortableAccel"),
            topDeceleration = str("Top deceleration", "topDeceleration"),
            smoothBraking = str("Smooth braking", "smoothBraking"),
            firmBraking = str("Firm braking", "firmBraking"),
            harshBraking = str("Harsh braking", "harshBraking"),
            emergencyBraking = str("Emergency braking", "emergencyBraking")
        )
    }

    fun sampleTrips(): List<Trip> = listOf(
        Trip(
            rowNumber = 2,
            startName = "Home",
            endName = "School",
            startLocation = "30.012777, 31.305487",
            endLocation = "29.997710, 31.296335",
            tripStartTime = "2026-11-24 07:19:28",
            tripEndTime = "2026-11-24 07:33:37",
            tripDuration = "PT00H14M07.000S",
            tripDistance = "8.42",
            maxSpeed = "100.16",
            tripAvgSpeed = "35.51",
            sharpTurns = "1",
            topLateralG = "0.447",
            chauffeurSmoothAccel = "0",
            comfortableEverydayAccel = "0",
            noticeableBriskAccel = "0",
            uncomfortableAccel = "0",
            topDeceleration = "4.23",
            smoothBraking = "22",
            firmBraking = "1",
            harshBraking = "2",
            emergencyBraking = "0"
        ),
        Trip(
            rowNumber = 3,
            startName = "School",
            endName = "Home",
            startLocation = "29.997698, 31.296346",
            endLocation = "30.012797, 31.305478",
            tripStartTime = "2026-11-24 07:39:24",
            tripEndTime = "2026-11-24 07:54:07",
            tripDuration = "PT00H14M41.000S",
            tripDistance = "8.50",
            maxSpeed = "76.55",
            tripAvgSpeed = "34.63",
            sharpTurns = "0",
            topLateralG = "0.287",
            chauffeurSmoothAccel = "0",
            comfortableEverydayAccel = "0",
            noticeableBriskAccel = "0",
            uncomfortableAccel = "0",
            topDeceleration = "3.55",
            smoothBraking = "24",
            firmBraking = "3",
            harshBraking = "1",
            emergencyBraking = "0"
        ),
        Trip(
            rowNumber = 4,
            startName = "Home",
            endName = "School",
            startLocation = "30.012675, 31.305465",
            endLocation = "29.997777, 31.296432",
            tripStartTime = "2026-11-24 14:13:28",
            tripEndTime = "2026-11-24 14:27:55",
            tripDuration = "PT00H14M25.000S",
            tripDistance = "8.44",
            maxSpeed = "103.02",
            tripAvgSpeed = "34.72",
            sharpTurns = "1",
            topLateralG = "0.377",
            chauffeurSmoothAccel = "0",
            comfortableEverydayAccel = "0",
            noticeableBriskAccel = "0",
            uncomfortableAccel = "0",
            topDeceleration = "5.52",
            smoothBraking = "29",
            firmBraking = "1",
            harshBraking = "4",
            emergencyBraking = "1"
        )
    )
}

package com.drivepulse.viewer.model

import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Trip(
    val rowNumber: Int,
    val startName: String,
    val endName: String,
    val startLocation: String,
    val endLocation: String,
    val tripStartTime: String,
    val tripEndTime: String,
    val tripDuration: String,
    val tripDistance: String,
    val maxSpeed: String,
    val tripAvgSpeed: String,
    val sharpTurns: String,
    val topLateralG: String,
    val chauffeurSmoothAccel: String,
    val comfortableEverydayAccel: String,
    val noticeableBriskAccel: String,
    val uncomfortableAccel: String,
    val topDeceleration: String,
    val smoothBraking: String,
    val firmBraking: String,
    val harshBraking: String,
    val emergencyBraking: String
) {
    fun formattedDate(): String {
        val parsed = parseDateTime(tripStartTime) ?: return tripStartTime.ifBlank { "Unknown Date" }
        return parsed.format(DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.US))
    }

    fun formattedTimeRange(): String {
        val start = parseDateTime(tripStartTime)
        val end = parseDateTime(tripEndTime)
        val timeFmt = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.US)
        return when {
            start != null && end != null -> "${start.format(timeFmt)} – ${end.format(timeFmt)}"
            start != null -> start.format(timeFmt)
            else -> listOf(tripStartTime, tripEndTime).filter { it.isNotBlank() }.joinToString(" – ")
        }
    }

    fun formattedDuration(): String {
        val raw = tripDuration.trim()
        if (raw.isEmpty()) return "--"
        val regex = Regex("""^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?$""", RegexOption.IGNORE_CASE)
        val match = regex.matchEntire(raw)
        if (match != null) {
            val hours = match.groupValues[1].toIntOrNull() ?: 0
            val minutes = match.groupValues[2].toIntOrNull() ?: 0
            val seconds = match.groupValues[3].toDoubleOrNull()?.toInt() ?: 0
            return buildString {
                if (hours > 0) append("${hours}h ")
                if (minutes > 0 || hours > 0) append("${minutes}m ")
                append(String.format(Locale.US, "%02ds", seconds))
            }.trim()
        }
        return raw
    }

    fun shortCoords(raw: String): String {
        val parts = raw.split(",").map { it.trim() }
        if (parts.size == 2) {
            val lat = parts[0].toDoubleOrNull()
            val lng = parts[1].toDoubleOrNull()
            if (lat != null && lng != null) {
                return String.format(Locale.US, "%.4f, %.4f", lat, lng)
            }
        }
        return raw.ifBlank { "N/A" }
    }

    fun formatDecimal(raw: String, decimals: Int = 2): String {
        val num = raw.trim().toDoubleOrNull() ?: return raw.ifBlank { "0" }
        return String.format(Locale.US, "%.${decimals}f", num)
    }

    fun formatInt(raw: String): String {
        val num = raw.trim().toDoubleOrNull() ?: return raw.ifBlank { "0" }
        return num.toInt().toString()
    }

    private fun parseDateTime(value: String): LocalDateTime? {
        val trimmed = value.trim()
        if (trimmed.isEmpty()) return null
        val formatters = listOf(
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd H:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"),
            DateTimeFormatter.ISO_LOCAL_DATE_TIME
        )
        for (fmt in formatters) {
            try {
                return LocalDateTime.parse(trimmed, fmt)
            } catch (_: Exception) { }
        }
        return try {
            OffsetDateTime.parse(trimmed).toLocalDateTime()
        } catch (_: Exception) {
            null
        }
    }
}

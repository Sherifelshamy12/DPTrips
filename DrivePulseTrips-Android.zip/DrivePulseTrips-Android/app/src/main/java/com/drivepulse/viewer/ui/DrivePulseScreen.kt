package com.drivepulse.viewer.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.drivepulse.viewer.model.Trip
import com.drivepulse.viewer.ui.theme.AmberAccent
import com.drivepulse.viewer.ui.theme.AmberTileBg
import com.drivepulse.viewer.ui.theme.BadgeGreenBg
import com.drivepulse.viewer.ui.theme.BadgeGreenText
import com.drivepulse.viewer.ui.theme.BadgeLimeBg
import com.drivepulse.viewer.ui.theme.BadgeLimeText
import com.drivepulse.viewer.ui.theme.BadgeOrangeBg
import com.drivepulse.viewer.ui.theme.BadgeOrangeText
import com.drivepulse.viewer.ui.theme.BadgeRedBg
import com.drivepulse.viewer.ui.theme.BadgeRedText
import com.drivepulse.viewer.ui.theme.CardSurface
import com.drivepulse.viewer.ui.theme.DeleteRed
import com.drivepulse.viewer.ui.theme.DividerSubtle
import com.drivepulse.viewer.ui.theme.PillSurface
import com.drivepulse.viewer.ui.theme.SlateBg
import com.drivepulse.viewer.ui.theme.TealAccent
import com.drivepulse.viewer.ui.theme.TealTileBg
import com.drivepulse.viewer.ui.theme.TextPrimary
import com.drivepulse.viewer.ui.theme.TextSecondary
import com.drivepulse.viewer.ui.theme.TileNeutral

@Composable
fun DrivePulseScreen(
    viewModel: DrivePulseViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var tripPendingDelete by remember { mutableStateOf<Trip?>(null) }

    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val pagerState = rememberPagerState(pageCount = { state.trips.size })

    Scaffold(
        containerColor = SlateBg,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            TopHeaderBar(
                currentIndex = if (state.trips.isNotEmpty()) pagerState.currentPage + 1 else 0,
                totalCount = state.trips.size,
                isDemo = state.isDemoMode,
                isLoading = state.isLoading,
                onRefresh = { viewModel.loadTrips() },
                onSettings = { showSettingsDialog = true }
            )

            Spacer(modifier = Modifier.height(12.dp))

            when {
                state.isLoading && state.trips.isEmpty() -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = TealAccent)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Syncing Sheet1...", color = TextSecondary, fontSize = 14.sp)
                        }
                    }
                }

                state.scriptUrl.isBlank() && !state.isDemoMode -> {
                    SetupWelcomeCard(
                        modifier = Modifier.weight(1f),
                        onOpenSettings = { showSettingsDialog = true },
                        onLoadDemo = { viewModel.loadDemoData() }
                    )
                }

                state.errorMessage != null && state.trips.isEmpty() -> {
                    ErrorStateCard(
                        modifier = Modifier.weight(1f),
                        message = state.errorMessage.orEmpty(),
                        onRetry = { viewModel.loadTrips() },
                        onSettings = { showSettingsDialog = true }
                    )
                }

                state.trips.isEmpty() -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "No trips found in Sheet1",
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Add rows to your DrivePulse sheet and tap Refresh.",
                                color = TextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                else -> {
                    if (state.errorMessage != null) {
                        Text(
                            text = state.errorMessage.orEmpty(),
                            color = DeleteRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        pageSpacing = 12.dp
                    ) { page ->
                        TripDetailCard(trip = state.trips[page])
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    PagerDotIndicator(
                        totalPages = state.trips.size,
                        currentPage = pagerState.currentPage
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    val currentTrip = state.trips.getOrNull(pagerState.currentPage)
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        OutlinedButton(
                            onClick = { tripPendingDelete = currentTrip },
                            enabled = currentTrip != null && !state.isDeleting,
                            shape = RoundedCornerShape(28.dp),
                            border = BorderStroke(1.5.dp, DeleteRed),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DeleteRed),
                            modifier = Modifier
                                .height(48.dp)
                                .width(200.dp)
                        ) {
                            if (state.isDeleting) {
                                CircularProgressIndicator(
                                    color = DeleteRed,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(18.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Delete Trip", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }

    if (showSettingsDialog) {
        SettingsUrlDialog(
            currentUrl = state.scriptUrl,
            onDismiss = { showSettingsDialog = false },
            onSave = { newUrl ->
                showSettingsDialog = false
                viewModel.saveScriptUrl(newUrl)
            }
        )
    }

    tripPendingDelete?.let { trip ->
        AlertDialog(
            onDismissRequest = { tripPendingDelete = null },
            containerColor = CardSurface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = { Text("Delete this trip?", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "This will permanently remove "${trip.startName} → ${trip.endName}" (${trip.formattedDate()}, ${trip.formattedTimeRange()}) from Sheet1."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        tripPendingDelete = null
                        viewModel.deleteTrip(trip)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DeleteRed,
                        contentColor = Color.White
                    )
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { tripPendingDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun TopHeaderBar(
    currentIndex: Int,
    totalCount: Int,
    isDemo: Boolean,
    isLoading: Boolean,
    onRefresh: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "DrivePulseTrips",
                color = TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            if (isDemo) {
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    color = AmberTileBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "DEMO",
                        color = AmberAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (totalCount > 0) {
                Text(
                    text = "Trip $currentIndex of $totalCount",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            IconButton(onClick = onRefresh, enabled = !isLoading) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = TealAccent,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(18.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Refresh",
                        tint = TextSecondary
                    )
                }
            }
            IconButton(onClick = onSettings) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "Sheet Settings",
                    tint = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun TripDetailCard(trip: Trip) {
    val context = LocalContext.current

    fun openMaps(coords: String, label: String) {
        val cleaned = coords.trim()
        if (cleaned.isBlank()) return
        val uri = Uri.parse("geo:$cleaned?q=$cleaned(${Uri.encode(label)})")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        try {
            context.startActivity(intent)
        } catch (_: Exception) { }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(24.dp),
        color = CardSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Trip on ${trip.formattedDate()}",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = trip.startName,
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = Icons.Rounded.ArrowForward,
                    contentDescription = null,
                    tint = TealAccent,
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .size(18.dp)
                )
                Text(
                    text = trip.endName,
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = trip.formattedTimeRange(),
                color = TextSecondary,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = PillSurface
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = TealAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = trip.shortCoords(trip.startLocation),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { openMaps(trip.startLocation, trip.startName) }
                    )
                    Text(
                        text = "  •  ",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = trip.shortCoords(trip.endLocation),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { openMaps(trip.endLocation, trip.endName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Route,
                    label = "Distance",
                    value = trip.formatDecimal(trip.tripDistance, 2),
                    unit = "km",
                    containerColor = TealTileBg,
                    accentColor = TealAccent
                )
                MetricTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Schedule,
                    label = "Duration",
                    value = trip.formattedDuration(),
                    unit = "",
                    containerColor = TealTileBg,
                    accentColor = TealAccent
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Speed,
                    label = "Max Speed",
                    value = trip.formatDecimal(trip.maxSpeed, 2),
                    unit = "km/h",
                    containerColor = AmberTileBg,
                    accentColor = AmberAccent
                )
                MetricTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Speed,
                    label = "Avg Speed",
                    value = trip.formatDecimal(trip.tripAvgSpeed, 2),
                    unit = "km/h",
                    containerColor = AmberTileBg,
                    accentColor = AmberAccent
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = TileNeutral
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MiniStatItem(
                        modifier = Modifier.weight(1f),
                        label = "Sharp Turns",
                        value = trip.formatInt(trip.sharpTurns)
                    )
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(32.dp)
                            .background(DividerSubtle)
                    )
                    MiniStatItem(
                        modifier = Modifier.weight(1f),
                        label = "Top Lateral G",
                        value = "${trip.formatDecimal(trip.topLateralG, 3)} G"
                    )
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(32.dp)
                            .background(DividerSubtle)
                    )
                    MiniStatItem(
                        modifier = Modifier.weight(1f),
                        label = "Top Decel",
                        value = trip.formatDecimal(trip.topDeceleration, 2)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EventBreakdownCard(
                    modifier = Modifier.weight(1f),
                    title = "Acceleration",
                    items = listOf(
                        BadgeItem("Smooth", trip.formatInt(trip.chauffeurSmoothAccel), BadgeGreenBg, BadgeGreenText),
                        BadgeItem("Everyday", trip.formatInt(trip.comfortableEverydayAccel), BadgeLimeBg, BadgeLimeText),
                        BadgeItem("Brisk", trip.formatInt(trip.noticeableBriskAccel), BadgeOrangeBg, BadgeOrangeText),
                        BadgeItem("Uncomf.", trip.formatInt(trip.uncomfortableAccel), BadgeRedBg, BadgeRedText)
                    )
                )
                EventBreakdownCard(
                    modifier = Modifier.weight(1f),
                    title = "Braking",
                    items = listOf(
                        BadgeItem("Smooth", trip.formatInt(trip.smoothBraking), BadgeGreenBg, BadgeGreenText),
                        BadgeItem("Firm", trip.formatInt(trip.firmBraking), BadgeOrangeBg, BadgeOrangeText),
                        BadgeItem("Harsh", trip.formatInt(trip.harshBraking), BadgeRedBg, BadgeRedText),
                        BadgeItem("Emerg.", trip.formatInt(trip.emergencyBraking), BadgeRedBg, BadgeRedText)
                    )
                )
            }
        }
    }
}

@Composable
private fun MetricTile(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    value: String,
    unit: String,
    containerColor: Color,
    accentColor: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = containerColor
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    color = accentColor,
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (unit.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = unit,
                        color = accentColor.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniStatItem(
    modifier: Modifier = Modifier,
    label: String,
    value: String
) {
    Column(
        modifier = modifier.padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

private data class BadgeItem(
    val label: String,
    val count: String,
    val bgColor: Color,
    val textColor: Color
)

@Composable
private fun EventBreakdownCard(
    modifier: Modifier = Modifier,
    title: String,
    items: List<BadgeItem>
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = TileNeutral
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))
            items.forEach { item ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = item.bgColor
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.label,
                            color = item.textColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = item.count,
                            color = item.textColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PagerDotIndicator(
    totalPages: Int,
    currentPage: Int
) {
    val maxDots = 7
    val count = minOf(totalPages, maxDots)
    val activeDot = if (totalPages <= maxDots) {
        currentPage
    } else {
        ((currentPage.toFloat() / (totalPages - 1).coerceAtLeast(1)) * (maxDots - 1)).toInt()
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until count) {
            val isSelected = i == activeDot
            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .height(7.dp)
                    .width(if (isSelected) 22.dp else 7.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) TealAccent else PillSurface)
            )
        }
    }
}

@Composable
private fun SetupWelcomeCard(
    modifier: Modifier = Modifier,
    onOpenSettings: () -> Unit,
    onLoadDemo: () -> Unit
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = CardSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Connect Your DrivePulse Sheet",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Paste your Google Apps Script Web App URL to load trips from Sheet1 and enable deleting rows directly from your phone.",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onOpenSettings,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TealAccent,
                        contentColor = Color(0xFF072220)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Set Google Sheet URL", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onLoadDemo,
                    border = BorderStroke(1.dp, DividerSubtle),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text("Preview with Sample Trips")
                }
            }
        }
    }
}

@Composable
private fun ErrorStateCard(
    modifier: Modifier = Modifier,
    message: String,
    onRetry: () -> Unit,
    onSettings: () -> Unit
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = CardSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Connection Issue",
                    color = DeleteRed,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = message,
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TealAccent,
                            contentColor = Color(0xFF072220)
                        )
                    ) {
                        Text("Retry", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onSettings,
                        border = BorderStroke(1.dp, DividerSubtle),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                    ) {
                        Text("Edit URL")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsUrlDialog(
    currentUrl: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember { mutableStateOf(currentUrl) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardSurface,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = { Text("DrivePulse Sheet URL", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Paste your deployed Google Apps Script Web App URL (ends with /exec):",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("https://script.google.com/macros/s/.../exec", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(text) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealAccent,
                    contentColor = Color(0xFF072220)
                )
            ) {
                Text("Save & Sync", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

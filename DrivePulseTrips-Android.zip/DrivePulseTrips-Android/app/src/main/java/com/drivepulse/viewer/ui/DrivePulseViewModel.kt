package com.drivepulse.viewer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drivepulse.viewer.data.PrefsManager
import com.drivepulse.viewer.data.SheetsRepository
import com.drivepulse.viewer.model.Trip
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DrivePulseUiState(
    val trips: List<Trip> = emptyList(),
    val isLoading: Boolean = false,
    val isDeleting: Boolean = false,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null,
    val scriptUrl: String = "",
    val isDemoMode: Boolean = false
)

class DrivePulseViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = PrefsManager(application)
    private val repository = SheetsRepository()

    private val _uiState = MutableStateFlow(
        DrivePulseUiState(scriptUrl = prefs.scriptUrl)
    )
    val uiState: StateFlow<DrivePulseUiState> = _uiState.asStateFlow()

    init {
        if (prefs.scriptUrl.isNotBlank()) {
            loadTrips()
        }
    }

    fun saveScriptUrl(url: String) {
        val cleaned = url.trim()
        prefs.scriptUrl = cleaned
        _uiState.update {
            it.copy(
                scriptUrl = cleaned,
                isDemoMode = false,
                errorMessage = null
            )
        }
        if (cleaned.isNotBlank()) {
            loadTrips()
        }
    }

    fun loadDemoData() {
        _uiState.update {
            it.copy(
                trips = repository.sampleTrips(),
                isDemoMode = true,
                isLoading = false,
                errorMessage = null,
                snackbarMessage = "Loaded sample trips (Demo Mode)"
            )
        }
    }

    fun loadTrips() {
        val url = _uiState.value.scriptUrl
        if (url.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please add your Google Apps Script URL in Settings.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, isDemoMode = false) }
            val result = repository.fetchTrips(url)
            result.fold(
                onSuccess = { trips ->
                    _uiState.update {
                        it.copy(
                            trips = trips,
                            isLoading = false,
                            errorMessage = null
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = error.message ?: "Failed to load trips from Sheet1."
                        )
                    }
                }
            )
        }
    }

    fun deleteTrip(trip: Trip) {
        if (_uiState.value.isDemoMode) {
            _uiState.update { state ->
                state.copy(
                    trips = state.trips.filterNot { it.rowNumber == trip.rowNumber },
                    snackbarMessage = "Trip removed (Demo Mode)"
                )
            }
            return
        }

        val url = _uiState.value.scriptUrl
        if (url.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isDeleting = true, errorMessage = null) }
            val result = repository.deleteTrip(url, trip.rowNumber, trip.tripStartTime)
            result.fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            isDeleting = false,
                            snackbarMessage = "Trip deleted from Sheet1"
                        )
                    }
                    loadTrips()
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isDeleting = false,
                            snackbarMessage = error.message ?: "Could not delete trip."
                        )
                    }
                }
            )
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}

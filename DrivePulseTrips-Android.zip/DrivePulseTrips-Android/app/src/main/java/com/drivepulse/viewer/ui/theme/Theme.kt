package com.drivepulse.viewer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val SlateBg = Color(0xFF0E1116)
val CardSurface = Color(0xFF1A1F29)
val TileNeutral = Color(0xFF232936)
val PillSurface = Color(0xFF2A3140)

val TealTileBg = Color(0xFF1A3134)
val TealAccent = Color(0xFF4FD1C5)

val AmberTileBg = Color(0xFF332A1D)
val AmberAccent = Color(0xFFF6C36A)

val TextPrimary = Color(0xFFF3F5F8)
val TextSecondary = Color(0xFFA0A9B8)
val DividerSubtle = Color(0xFF2E3545)

val BadgeGreenBg = Color(0xFF214A37)
val BadgeGreenText = Color(0xFF7BE3AC)

val BadgeLimeBg = Color(0xFF444821)
val BadgeLimeText = Color(0xFFE4EE88)

val BadgeOrangeBg = Color(0xFF4D341E)
val BadgeOrangeText = Color(0xFFFBB36B)

val BadgeRedBg = Color(0xFF4E2326)
val BadgeRedText = Color(0xFFFF8A84)

val DeleteRed = Color(0xFFEF6B63)

private val DrivePulseDarkColors = darkColorScheme(
    primary = TealAccent,
    onPrimary = Color(0xFF072220),
    secondary = AmberAccent,
    background = SlateBg,
    onBackground = TextPrimary,
    surface = CardSurface,
    onSurface = TextPrimary,
    surfaceVariant = TileNeutral,
    onSurfaceVariant = TextSecondary,
    error = DeleteRed
)

@Composable
fun DrivePulseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DrivePulseDarkColors,
        content = content
    )
}

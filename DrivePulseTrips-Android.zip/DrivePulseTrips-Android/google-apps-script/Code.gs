/**
 * DrivePulse Google Sheets Bridge
 * Paste this into Extensions -> Apps Script inside your "DrivePulse" Google Sheet.
 * Deploy -> New deployment -> Web app -> Execute as: Me -> Who has access: Anyone.
 */

const SHEET_NAME = 'Sheet1';

function doGet(e) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      return jsonResponse({ status: 'error', message: 'Sheet1 not found.' });
    }

    const values = sheet.getDataRange().getDisplayValues();
    if (values.length <= 1) {
      return jsonResponse({ status: 'ok', trips: [] });
    }

    const headers = values[0].map(h => String(h).trim());
    const trips = [];

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const isEmpty = row.every(cell => String(cell).trim() === '');
      if (isEmpty) continue;

      const trip = { rowNumber: i + 1 }; // 1-based row index in Google Sheets
      for (let c = 0; c < headers.length; c++) {
        if (headers[c]) {
          trip[headers[c]] = row[c] !== undefined ? String(row[c]).trim() : '';
        }
      }
      trips.push(trip);
    }

    return jsonResponse({ status: 'ok', trips: trips });
  } catch (err) {
    return jsonResponse({ status: 'error', message: err.toString() });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    if (body.action !== 'deleteTrip') {
      return jsonResponse({ status: 'error', message: 'Unsupported action.' });
    }

    const rowNumber = parseInt(body.rowNumber, 10);
    if (!rowNumber || rowNumber < 2) {
      return jsonResponse({ status: 'error', message: 'Invalid rowNumber.' });
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      return jsonResponse({ status: 'error', message: 'Sheet1 not found.' });
    }

    if (rowNumber > sheet.getLastRow()) {
      return jsonResponse({ status: 'error', message: 'Row already deleted.' });
    }

    // Safety check against Trip start time so we never delete the wrong row
    if (body.tripStartTime) {
      const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getDisplayValues()[0];
      const startColIdx = headers.findIndex(h => String(h).trim() === 'Trip start time');
      if (startColIdx !== -1) {
        const cellVal = String(sheet.getRange(rowNumber, startColIdx + 1).getDisplayValue()).trim();
        if (cellVal && cellVal !== String(body.tripStartTime).trim()) {
          return jsonResponse({
            status: 'error',
            message: 'Sheet changed since last sync. Please tap Refresh and try again.'
          });
        }
      }
    }

    sheet.deleteRow(rowNumber);
    return jsonResponse({ status: 'ok', deletedRow: rowNumber });
  } catch (err) {
    return jsonResponse({ status: 'error', message: err.toString() });
  }
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

package com.drivepulse.viewer.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.drivepulse.viewer.model.Trip
import com.drivepulse.viewer.ui.theme.AmberAccent
import com.drivepulse.viewer.ui.theme.AmberTileBg
import com.drivepulse.viewer.ui.theme.BadgeGreenBg
import com.drivepulse.viewer.ui.theme.BadgeGreenText
import com.drivepulse.viewer.ui.theme.BadgeLimeBg
import com.drivepulse.viewer.ui.theme.BadgeLimeText
import com.drivepulse.viewer.ui.theme.BadgeOrangeBg
import com.drivepulse.viewer.ui.theme.BadgeOrangeText
import com.drivepulse.viewer.ui.theme.BadgeRedBg
import com.drivepulse.viewer.ui.theme.BadgeRedText
import com.drivepulse.viewer.ui.theme.CardSurface
import com.drivepulse.viewer.ui.theme.DeleteRed
import com.drivepulse.viewer.ui.theme.DividerSubtle
import com.drivepulse.viewer.ui.theme.PillSurface
import com.drivepulse.viewer.ui.theme.SlateBg
import com.drivepulse.viewer.ui.theme.TealAccent
import com.drivepulse.viewer.ui.theme.TealTileBg
import com.drivepulse.viewer.ui.theme.TextPrimary
import com.drivepulse.viewer.ui.theme.TextSecondary
import com.drivepulse.viewer.ui.theme.TileNeutral

@Composable
fun DrivePulseScreen(
    viewModel: DrivePulseViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val trips = state.filteredTrips
    val snackbarHostState = remember { SnackbarHostState() }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var tripPendingDelete by remember { mutableStateOf<Trip?>(null) }

    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val pagerState = rememberPagerState(pageCount = { trips.size })

    // Jump back to page 0 (latest trip) whenever filters change
    LaunchedEffect(state.selectedStartFilter, state.selectedEndFilter) {
        if (trips.isNotEmpty()) {
            pagerState.scrollToPage(0)
        }
    }

    val safeCurrentPage = if (trips.isNotEmpty()) {
        pagerState.currentPage.coerceIn(0, trips.size - 1)
    } else {
        0
    }

    Scaffold(
        containerColor = SlateBg,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            TopHeaderBar(
                currentIndex = if (trips.isNotEmpty()) safeCurrentPage + 1 else 0,
                totalCount = trips.size,
                isDemo = state.isDemoMode,
                isLoading = state.isLoading,
                onRefresh = { viewModel.loadTrips() },
                onSettings = { showSettingsDialog = true }
            )

            if (state.allTrips.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                LocationFilterBar(
                    startOptions = state.startLocationOptions,
                    endOptions = state.endLocationOptions,
                    selectedStart = state.selectedStartFilter,
                    selectedEnd = state.selectedEndFilter,
                    hasActiveFilter = state.hasActiveFilter,
                    onSelectStart = { viewModel.setStartFilter(it) },
                    onSelectEnd = { viewModel.setEndFilter(it) },
                    onClear = { viewModel.clearFilters() }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            when {
                state.isLoading && state.allTrips.isEmpty() -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = TealAccent)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Syncing Sheet1...", color = TextSecondary, fontSize = 13.sp)
                        }
                    }
                }

                state.scriptUrl.isBlank() && !state.isDemoMode -> {
                    SetupWelcomeCard(
                        modifier = Modifier.weight(1f),
                        onOpenSettings = { showSettingsDialog = true },
                        onLoadDemo = { viewModel.loadDemoData() }
                    )
                }

                state.errorMessage != null && state.allTrips.isEmpty() -> {
                    ErrorStateCard(
                        modifier = Modifier.weight(1f),
                        message = state.errorMessage.orEmpty(),
                        onRetry = { viewModel.loadTrips() },
                        onSettings = { showSettingsDialog = true }
                    )
                }

                state.allTrips.isEmpty() -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "No trips found in Sheet1",
                                color = TextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Add rows to your DrivePulse sheet and tap Refresh.",
                                color = TextSecondary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                trips.isEmpty() -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = CardSurface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    "No trips match this filter",
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "Try another Start/End combination or clear filters.",
                                    color = TextSecondary,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = { viewModel.clearFilters() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = TealAccent,
                                        contentColor = Color(0xFF072220)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Clear Filters", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                else -> {
                    if (state.errorMessage != null) {
                        Text(
                            text = state.errorMessage.orEmpty(),
                            color = DeleteRed,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        pageSpacing = 10.dp
                    ) { page ->
                        TripDetailCard(trip = trips[page])
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    PagerDotIndicator(
                        totalPages = trips.size,
                        currentPage = safeCurrentPage
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val currentTrip = trips.getOrNull(safeCurrentPage)
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        OutlinedButton(
                            onClick = { tripPendingDelete = currentTrip },
                            enabled = currentTrip != null && !state.isDeleting,
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.3.dp, DeleteRed),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DeleteRed),
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(40.dp)
                                .width(176.dp)
                        ) {
                            if (state.isDeleting) {
                                CircularProgressIndicator(
                                    color = DeleteRed,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Delete Trip", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                }
            }
        }
    }

    if (showSettingsDialog) {
        SettingsUrlDialog(
            currentUrl = state.scriptUrl,
            onDismiss = { showSettingsDialog = false },
            onSave = { newUrl ->
                showSettingsDialog = false
                viewModel.saveScriptUrl(newUrl)
            }
        )
    }

    tripPendingDelete?.let { trip ->
        AlertDialog(
            onDismissRequest = { tripPendingDelete = null },
            containerColor = CardSurface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = { Text("Confirm Delete", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Are you sure you want to permanently delete \"${trip.startName} → ${trip.endName}\" (${trip.formattedDate()}, ${trip.formattedTimeRange()}) from Sheet1?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        tripPendingDelete = null
                        viewModel.deleteTrip(trip)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DeleteRed,
                        contentColor = Color.White
                    )
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { tripPendingDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun TopHeaderBar(
    currentIndex: Int,
    totalCount: Int,
    isDemo: Boolean,
    isLoading: Boolean,
    onRefresh: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "DrivePulseTrips",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            if (isDemo) {
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                    color = AmberTileBg,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "DEMO",
                        color = AmberAccent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (totalCount > 0) {
                Text(
                    text = "Trip $currentIndex of $totalCount",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            IconButton(
                onClick = onRefresh,
                enabled = !isLoading,
                modifier = Modifier.size(34.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = TealAccent,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Refresh",
                        tint = TextSecondary,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
            IconButton(
                onClick = onSettings,
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "Sheet Settings",
                    tint = TextSecondary,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

@Composable
private fun LocationFilterBar(
    startOptions: List<String>,
    endOptions: List<String>,
    selectedStart: String?,
    selectedEnd: String?,
    hasActiveFilter: Boolean,
    onSelectStart: (String?) -> Unit,
    onSelectEnd: (String?) -> Unit,
    onClear: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilterDropdownChip(
            modifier = Modifier.weight(1f),
            prefix = "Start",
            selectedValue = selectedStart,
            options = startOptions,
            onSelect = onSelectStart
        )
        FilterDropdownChip(
            modifier = Modifier.weight(1f),
            prefix = "End",
            selectedValue = selectedEnd,
            options = endOptions,
            onSelect = onSelectEnd
        )
        Surface(
            shape = CircleShape,
            color = if (hasActiveFilter) PillSurface else CardSurface,
            border = BorderStroke(1.dp, if (hasActiveFilter) TealAccent.copy(alpha = 0.5f) else DividerSubtle),
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .clickable(enabled = hasActiveFilter) { onClear() }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Clear Filters",
                    tint = if (hasActiveFilter) TextPrimary else TextSecondary.copy(alpha = 0.4f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun FilterDropdownChip(
    modifier: Modifier = Modifier,
    prefix: String,
    selectedValue: String?,
    options: List<String>,
    onSelect: (String?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = PillSurface,
            border = BorderStroke(
                1.dp,
                if (selectedValue != null) TealAccent.copy(alpha = 0.6f) else DividerSubtle
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(RoundedCornerShape(18.dp))
                .clickable { expanded = true }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(color = TextSecondary, fontWeight = FontWeight.Normal)) {
                            append("$prefix: ")
                        }
                        withStyle(
                            SpanStyle(
                                color = if (selectedValue != null) TealAccent else TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        ) {
                            append(selectedValue ?: "All")
                        }
                    },
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.Rounded.ArrowDropDown,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CardSurface)
        ) {
            DropdownMenuItem(
                text = {
                    Text(
                        text = "All",
                        color = if (selectedValue == null) TealAccent else TextPrimary,
                        fontWeight = if (selectedValue == null) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 13.sp
                    )
                },
                onClick = {
                    expanded = false
                    onSelect(null)
                }
            )
            options.forEach { option ->
                val isSelected = option.equals(selectedValue, ignoreCase = true)
                DropdownMenuItem(
                    text = {
                        Text(
                            text = option,
                            color = if (isSelected) TealAccent else TextPrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    onClick = {
                        expanded = false
                        onSelect(option)
                    }
                )
            }
        }
    }
}

@Composable
private fun TripDetailCard(trip: Trip) {
    val context = LocalContext.current

    fun openMaps(coords: String, label: String) {
        val cleaned = coords.trim()
        if (cleaned.isBlank()) return
        val uri = Uri.parse("geo:$cleaned?q=$cleaned(${Uri.encode(label)})")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        try {
            context.startActivity(intent)
        } catch (_: Exception) { }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(20.dp),
        color = CardSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Compact Date, Route & GPS Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = trip.formattedDateAndTime(),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(3.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = trip.startName,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Icon(
                        imageVector = Icons.Rounded.ArrowForward,
                        contentDescription = null,
                        tint = TealAccent,
                        modifier = Modifier
                            .padding(horizontal = 6.dp)
                            .size(15.dp)
                    )
                    Text(
                        text = trip.endName,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = PillSurface
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocationOn,
                            contentDescription = null,
                            tint = TealAccent,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = trip.shortCoords(trip.startLocation),
                            color = TextSecondary,
                            fontSize = 10.sp,
                            modifier = Modifier.clickable { openMaps(trip.startLocation, trip.startName) }
                        )
                        Text(
                            text = "  •  ",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = trip.shortCoords(trip.endLocation),
                            color = TextSecondary,
                            fontSize = 10.sp,
                            modifier = Modifier.clickable { openMaps(trip.endLocation, trip.endName) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Compact 2x2 Core Telemetry Grid
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricTile(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Route,
                        label = "Distance",
                        value = trip.formatDecimal(trip.tripDistance, 2),
                        unit = "km",
                        containerColor = TealTileBg,
                        accentColor = TealAccent
                    )
                    MetricTile(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Schedule,
                        label = "Duration",
                        value = trip.formattedDuration(),
                        unit = "",
                        containerColor = TealTileBg,
                        accentColor = TealAccent
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricTile(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Speed,
                        label = "Max Speed",
                        value = trip.formatDecimal(trip.maxSpeed, 2),
                        unit = "km/h",
                        containerColor = AmberTileBg,
                        accentColor = AmberAccent
                    )
                    MetricTile(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Speed,
                        label = "Avg Speed",
                        value = trip.formatDecimal(trip.tripAvgSpeed, 2),
                        unit = "km/h",
                        containerColor = AmberTileBg,
                        accentColor = AmberAccent
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Slim 3-Column Handling Strip
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = TileNeutral
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MiniStatItem(
                        modifier = Modifier.weight(1f),
                        label = "Sharp Turns",
                        value = trip.formatInt(trip.sharpTurns)
                    )
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(26.dp)
                            .background(DividerSubtle)
                    )
                    MiniStatItem(
                        modifier = Modifier.weight(1f),
                        label = "Top Lateral G",
                        value = "${trip.formatDecimal(trip.topLateralG, 3)} G"
                    )
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(26.dp)
                            .background(DividerSubtle)
                    )
                    MiniStatItem(
                        modifier = Modifier.weight(1f),
                        label = "Top Decel",
                        value = trip.formatDecimal(trip.topDeceleration, 2)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Compact 2x2 Pill Grid for Acceleration & Braking
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EventBreakdownCard(
                    modifier = Modifier.weight(1f),
                    title = "Acceleration",
                    topRow = listOf(
                        BadgeItem("Smooth", trip.formatInt(trip.chauffeurSmoothAccel), BadgeGreenBg, BadgeGreenText),
                        BadgeItem("Every.", trip.formatInt(trip.comfortableEverydayAccel), BadgeLimeBg, BadgeLimeText)
                    ),
                    bottomRow = listOf(
                        BadgeItem("Brisk", trip.formatInt(trip.noticeableBriskAccel), BadgeOrangeBg, BadgeOrangeText),
                        BadgeItem("Uncomf", trip.formatInt(trip.uncomfortableAccel), BadgeRedBg, BadgeRedText)
                    )
                )
                EventBreakdownCard(
                    modifier = Modifier.weight(1f),
                    title = "Braking",
                    topRow = listOf(
                        BadgeItem("Smooth", trip.formatInt(trip.smoothBraking), BadgeGreenBg, BadgeGreenText),
                        BadgeItem("Firm", trip.formatInt(trip.firmBraking), BadgeOrangeBg, BadgeOrangeText)
                    ),
                    bottomRow = listOf(
                        BadgeItem("Harsh", trip.formatInt(trip.harshBraking), BadgeRedBg, BadgeRedText),
                        BadgeItem("Emerg", trip.formatInt(trip.emergencyBraking), BadgeRedBg, BadgeRedText)
                    )
                )
            }
        }
    }
}

@Composable
private fun MetricTile(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    value: String,
    unit: String,
    containerColor: Color,
    accentColor: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = containerColor
    ) {
        Column(modifier = Modifier.padding(horizontal = 11.dp, vertical = 9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = label,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    color = accentColor,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (unit.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = unit,
                        color = accentColor.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniStatItem(
    modifier: Modifier = Modifier,
    label: String,
    value: String
) {
    Column(
        modifier = modifier.padding(horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

private data class BadgeItem(
    val label: String,
    val count: String,
    val bgColor: Color,
    val textColor: Color
)

@Composable
private fun EventBreakdownCard(
    modifier: Modifier = Modifier,
    title: String,
    topRow: List<BadgeItem>,
    bottomRow: List<BadgeItem>
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = TileNeutral
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                topRow.forEach { item ->
                    CompactBadgePill(item = item, modifier = Modifier.weight(1f))
                }
            }
            Spacer(modifier = Modifier.height(5.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                bottomRow.forEach { item ->
                    CompactBadgePill(item = item, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun CompactBadgePill(
    item: BadgeItem,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = item.bgColor
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = item.label,
                color = item.textColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = item.count,
                color = item.textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PagerDotIndicator(
    totalPages: Int,
    currentPage: Int
) {
    val maxDots = 7
    val count = minOf(totalPages, maxDots)
    val activeDot = if (totalPages <= maxDots) {
        currentPage
    } else {
        ((currentPage.toFloat() / (totalPages - 1).coerceAtLeast(1)) * (maxDots - 1)).toInt()
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until count) {
            val isSelected = i == activeDot
            Box(
                modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .height(6.dp)
                    .width(if (isSelected) 20.dp else 6.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) TealAccent else PillSurface)
            )
        }
    }
}

@Composable
private fun SetupWelcomeCard(
    modifier: Modifier = Modifier,
    onOpenSettings: () -> Unit,
    onLoadDemo: () -> Unit
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = CardSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Connect Your DrivePulse Sheet",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Paste your Google Apps Script Web App URL to load trips from Sheet1 and enable deleting rows directly from your phone.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(18.dp))
                Button(
                    onClick = onOpenSettings,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TealAccent,
                        contentColor = Color(0xFF072220)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text("Set Google Sheet URL", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onLoadDemo,
                    border = BorderStroke(1.dp, DividerSubtle),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Text("Preview with Sample Trips")
                }
            }
        }
    }
}

@Composable
private fun ErrorStateCard(
    modifier: Modifier = Modifier,
    message: String,
    onRetry: () -> Unit,
    onSettings: () -> Unit
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = CardSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Connection Issue",
                    color = DeleteRed,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = message,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TealAccent,
                            contentColor = Color(0xFF072220)
                        )
                    ) {
                        Text("Retry", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onSettings,
                        border = BorderStroke(1.dp, DividerSubtle),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                    ) {
                        Text("Edit URL")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsUrlDialog(
    currentUrl: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember { mutableStateOf(currentUrl) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardSurface,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = { Text("DrivePulse Sheet URL", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Paste your deployed Google Apps Script Web App URL (ends with /exec):",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("https://script.google.com/macros/s/.../exec", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(text) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealAccent,
                    contentColor = Color(0xFF072220)
                )
            ) {
                Text("Save & Sync", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

package com.drivepulse.viewer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drivepulse.viewer.data.PrefsManager
import com.drivepulse.viewer.data.SheetsRepository
import com.drivepulse.viewer.model.Trip
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DrivePulseUiState(
    val allTrips: List<Trip> = emptyList(),
    val selectedStartFilter: String? = null,
    val selectedEndFilter: String? = null,
    val isLoading: Boolean = false,
    val isDeleting: Boolean = false,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null,
    val scriptUrl: String = "",
    val isDemoMode: Boolean = false
) {
    val startLocationOptions: List<String>
        get() = allTrips.map { it.startName }.filter { it.isNotBlank() }.distinct().sorted()

    val endLocationOptions: List<String>
        get() = allTrips.map { it.endName }.filter { it.isNotBlank() }.distinct().sorted()

    val hasActiveFilter: Boolean
        get() = selectedStartFilter != null || selectedEndFilter != null

    val filteredTrips: List<Trip>
        get() = allTrips.filter { trip ->
            val matchStart = selectedStartFilter == null || trip.startName.equals(selectedStartFilter, ignoreCase = true)
            val matchEnd = selectedEndFilter == null || trip.endName.equals(selectedEndFilter, ignoreCase = true)
            matchStart && matchEnd
        }
}

class DrivePulseViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = PrefsManager(application)
    private val repository = SheetsRepository()

    private val _uiState = MutableStateFlow(
        DrivePulseUiState(scriptUrl = prefs.scriptUrl)
    )
    val uiState: StateFlow<DrivePulseUiState> = _uiState.asStateFlow()

    init {
        if (prefs.scriptUrl.isNotBlank()) {
            loadTrips()
        }
    }

    private fun sortNewestFirst(trips: List<Trip>): List<Trip> {
        return trips.sortedWith(
            compareByDescending<Trip> { it.sortTimestamp() }
                .thenByDescending { it.rowNumber }
        )
    }

    fun saveScriptUrl(url: String) {
        val cleaned = url.trim()
        prefs.scriptUrl = cleaned
        _uiState.update {
            it.copy(
                scriptUrl = cleaned,
                isDemoMode = false,
                errorMessage = null
            )
        }
        if (cleaned.isNotBlank()) {
            loadTrips()
        }
    }

    fun setStartFilter(location: String?) {
        _uiState.update { it.copy(selectedStartFilter = location) }
    }

    fun setEndFilter(location: String?) {
        _uiState.update { it.copy(selectedEndFilter = location) }
    }

    fun clearFilters() {
        _uiState.update { it.copy(selectedStartFilter = null, selectedEndFilter = null) }
    }

    fun loadDemoData() {
        _uiState.update {
            it.copy(
                allTrips = sortNewestFirst(repository.sampleTrips()),
                selectedStartFilter = null,
                selectedEndFilter = null,
                isDemoMode = true,
                isLoading = false,
                errorMessage = null,
                snackbarMessage = "Loaded sample trips (Demo Mode)"
            )
        }
    }

    fun loadTrips() {
        val url = _uiState.value.scriptUrl
        if (url.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please add your Google Apps Script URL in Settings.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, isDemoMode = false) }
            val result = repository.fetchTrips(url)
            result.fold(
                onSuccess = { trips ->
                    val sorted = sortNewestFirst(trips)
                    _uiState.update {
                        it.copy(
                            allTrips = sorted,
                            isLoading = false,
                            errorMessage = null
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = error.message ?: "Failed to load trips from Sheet1."
                        )
                    }
                }
            )
        }
    }

    fun deleteTrip(trip: Trip) {
        if (_uiState.value.isDemoMode) {
            _uiState.update { state ->
                state.copy(
                    allTrips = state.allTrips.filterNot { it.rowNumber == trip.rowNumber },
                    snackbarMessage = "Trip removed (Demo Mode)"
                )
            }
            return
        }

        val url = _uiState.value.scriptUrl
        if (url.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isDeleting = true, errorMessage = null) }
            val result = repository.deleteTrip(url, trip.rowNumber, trip.tripStartTime)
            result.fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            isDeleting = false,
                            snackbarMessage = "Trip deleted from Sheet1"
                        )
                    }
                    loadTrips()
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isDeleting = false,
                            snackbarMessage = error.message ?: "Could not delete trip."
                        )
                    }
                }
            )
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
